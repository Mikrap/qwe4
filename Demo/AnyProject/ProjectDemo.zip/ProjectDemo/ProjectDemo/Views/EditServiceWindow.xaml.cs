﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для EditServiceWindow.xaml
    /// </summary>
    public partial class EditServiceWindow : Window
    {
        private readonly HotelServices _service;

        public EditServiceWindow(HotelServices service)
        {
            InitializeComponent();
            _service = service;
            ServiceNameTextBox.Text = service.ServiceName;
            PriceTextBox.Text = service.Price.ToString();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ServiceNameTextBox.Text) ||
                !decimal.TryParse(PriceTextBox.Text, out decimal price))
            {
                MessageBox.Show("Заполните все поля корректно");
                return;
            }

            using (var context = new DatabaseContext())
            {
                var serviceToUpdate = context.HotelServices.Find(_service.ServiceID);
                if (serviceToUpdate != null)
                {
                    serviceToUpdate.ServiceName = ServiceNameTextBox.Text;
                    serviceToUpdate.Price = price;
                    context.SaveChanges();
                }
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
