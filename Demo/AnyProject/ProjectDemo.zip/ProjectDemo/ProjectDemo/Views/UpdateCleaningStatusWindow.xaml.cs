﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для UpdateCleaningStatusWindow.xaml
    /// </summary>
    public partial class UpdateCleaningStatusWindow : Window
    {
        private readonly RoomCleaning _cleaning;

        public UpdateCleaningStatusWindow(RoomCleaning cleaning)
        {
            InitializeComponent();
            _cleaning = cleaning;
            CurrentStatusTextBlock.Text = cleaning.Status;
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            if (StatusComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите новый статус");
                return;
            }

            var newStatus = ((ComboBoxItem)StatusComboBox.SelectedItem).Content.ToString();

            using (var context = new DatabaseContext())
            {
                var cleaningToUpdate = context.RoomCleanings.Find(_cleaning.CleaningID);
                if (cleaningToUpdate != null)
                {
                    cleaningToUpdate.Status = newStatus;

                    // Обновляем статус номера, если уборка завершена
                    if (newStatus == "Завершена")
                    {
                        var room = context.Rooms.Find(_cleaning.RoomID);
                        if (room != null)
                        {
                            room.RoomStatus = "Чистый";
                        }
                    }

                    context.SaveChanges();
                }
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
