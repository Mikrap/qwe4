﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AdminDashboard.xaml
    /// </summary>
    public partial class AdminDashboard : Window
    {
        public AdminDashboard()
        {
            InitializeComponent();
            MainFrame.Content = new ClientsView();
        }

        private void ClientsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new ClientsView();
        }

        private void RoomsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new RoomsView();
        }

        private void OrdersMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new OrdersView();
        }

        private void CleaningMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new CleaningView();
        }

        private void ServicesMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new ServicesView();
        }

        private void PaymentsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new PaymentsView();
        }

        private void ReportsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new ReportsView();
        }

        private void LogoutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            var authWindow = new AuthWindow();
            authWindow.Show();
            this.Close();
        }
    }
}
